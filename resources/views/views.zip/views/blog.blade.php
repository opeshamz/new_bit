@extends('layouts.sub-front')
@section('content')

<div class="gradient-bg title-wrap">
    <div class="row">
        <div class="col-lg-12 col-md-12 whitecolor">
            <h3 class="float-left">About Our Company</h3>
            <ul class="breadcrumb top10 bottom10 float-right">
            <li class="breadcrumb-item hover-light"><a href="{{url('/')}}">Home</a></li>
                <li class="breadcrumb-item hover-light">About</li>
            </ul>
        </div>
    </div>
</div>
</div>
</section>

<section id="our-blog" class="bglight padding_top padding_bottom_half">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left">
                    <div class="blog-img">
                        <a class="image" href="blog-detail.html">
                            <img src="images/blog-1.jpg" alt="Latest News" class="img-responsive">
                        </a>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">28 Ways to Boost Your Content Confidence</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Feb 14</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> Peter </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>8</a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left">
                    <div class="blog-img">
                        <a class="image" href="blog-detail.html">
                            <img src="images/blog-2.jpg" alt="Latest News" class="img-responsive">
                        </a>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">Next Large Social Network</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Sep 16</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> John </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>17 </a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left">
                    <div class="blog-img">
                        <a class="image" href="blog-detail.html">
                            <img src="images/blog-3.jpg" alt="Latest News" class="img-responsive">
                        </a>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">Smart Choices that Lead to Success</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Jan 13</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> David </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>8 </a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left">
                    <div class="blog-img">
                        <div class="owl-carousel owl-theme owl-blog-item owl-loaded owl-drag">
                            
                            
                            
                            
                        <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-700px, 0px, 0px); transition: all 0s ease 0s; width: 2800px;"><div class="owl-item cloned" style="width: 350px;"><div class="image item">
                                <img src="images/blog-2.jpg" alt="image">
                            </div></div><div class="owl-item cloned" style="width: 350px;"><div class="image item">
                                <img src="images/blog-6.jpg" alt="image">
                            </div></div><div class="owl-item active" style="width: 350px;"><div class="image item">
                                <img src="images/blog-4.jpg" alt="image">
                            </div></div><div class="owl-item" style="width: 350px;"><div class="image item">
                                <img src="images/blog-3.jpg" alt="image">
                            </div></div><div class="owl-item" style="width: 350px;"><div class="image item">
                                <img src="images/blog-2.jpg" alt="image">
                            </div></div><div class="owl-item" style="width: 350px;"><div class="image item">
                                <img src="images/blog-6.jpg" alt="image">
                            </div></div><div class="owl-item cloned" style="width: 350px;"><div class="image item">
                                <img src="images/blog-4.jpg" alt="image">
                            </div></div><div class="owl-item cloned" style="width: 350px;"><div class="image item">
                                <img src="images/blog-3.jpg" alt="image">
                            </div></div></div></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><i class="fas fa-long-arrow-alt-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="fas fa-long-arrow-alt-right"></i></button></div><div class="owl-dots disabled"></div></div>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">5 Practical Time Management Tips</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Apr 14</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> Harry </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>6 </a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left">
                    <div class="blog-img">
                        <a data-fancybox="" href="video/video.mp4">
                            <div class="play-hvr">
                                <div class="play-icon">
                                    <i class="fas fa-play"></i>
                                </div>
                            </div>
                        </a>
                        <div class="image">
                            <img src="images/blog-5.jpg" alt="Latest News" class="img-responsive">
                        </div>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">11 Ways to Stay an Alert Copywriter</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Mar 14</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> Sonia </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>19 </a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="news_item shadow text-center text-md-left last-blog">
                    <div class="blog-img">
                        <a class="image" href="blog-detail.html">
                            <img src="images/blog-6.jpg" alt="Latest News" class="img-responsive">
                        </a>
                    </div>
                    <div class="news_desc">
                        <h3 class="text-capitalize font-normal darkcolor"><a href="blog-detail.html">Creative Self-Care to Keep Your Writing</a></h3>
                        <ul class="meta-tags top20 bottom20">
                            <li><a href="#."><i class="fas fa-calendar-alt"></i>Sep 26</a></li>
                            <li><a href="#."> <i class="far fa-user"></i> Varun </a></li>
                            <li><a href="#."><i class="far fa-comment-dots"></i>12 </a></li>
                        </ul>
                        <p>Lorem Ipsum is simply dummy text of the printing industry. Lorem has been dummy text ever since the 1500s...</p>
                        <a href="blog-detail.html" class="button gradient-btn">Read more</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <!--Pagination-->
                <ul class="pagination justify-content-center top25 mb-4 mb-md-0 mb-sm-3">
                    <li class="page-item"><a class="page-link disabled" href="#."><i class="fa fa-angle-left"></i></a></li>
                    <li class="page-item active"><a class="page-link" href="#.">1</a></li>
                    <li class="page-item"><a class="page-link" href="#.">2</a></li>
                    <li class="page-item"><a class="page-link" href="#.">3</a></li>
                    <li class="page-item"><a class="page-link" href="#."><i class="fa fa-angle-right"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- Our Team ends-->
@endsection
