
<br><br>
{{ $user_query }} <br>

