@extends('layouts.sub-front')
@section('content')
<div class="gradient-bg title-wrap">
    <div class="row">
        <div class="col-lg-12 col-md-12 whitecolor">
            <h3 class="float-left">Career</h3>
            <ul class="breadcrumb top10 bottom10 float-right">
                <li class="breadcrumb-item hover-light"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item hover-light">Career</li>
            </ul>
        </div>
    </div>
</div>
</div>
</section>
<!--Page Header ends -->
<br> <br><br> <br><br> <br><br> <br>
<h1 style="text-align: center;">NO JOB OFFER YET (COMING SOON).</h1>



@endsection
